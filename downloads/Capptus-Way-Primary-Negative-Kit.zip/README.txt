THE CAPPTUS WAY — PRIMARY SIDE-BY-SIDE / NEGATIVE
October 2, 2026

The user requested an enlarged negative of the side-by-side Sello layout as the main Capptus Way signature. This version pairs white linework and outlined Lora lettering with sand accents on Capptus blue #008ED1.

Primary-Negative: transparent SVG and PNG for placement over blue or dark surfaces.
Primary-Blue: SVG and PNG with Capptus-blue background.
Primary-Blue-Large: enlarged 2400 x 1200 presentation plate.

Typography is outlined native vector geometry; no fonts are required. Preserve aspect ratio. Use the transparent master for placement and the blue plate for presentation. The corporate Capptus logo is unchanged.

SVG structure and PNG transparency verified; enlarged plate inspected visually. Physical production proofs have not been performed.
