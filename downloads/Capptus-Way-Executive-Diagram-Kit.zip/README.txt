THE CAPPTUS WAY — EXECUTIVE DIAGRAM
16:9 methodology composition, October 2, 2026.

Use the 3840 x 2160 PNG for immediate insertion into a slide. The SVG has outlined typography and embedded original illustrations. Both preserve the intended Lora and Montserrat rendering without installed fonts.

The one-slide PPTX contains 38 editable text boxes, 11 native connectors and eight embedded artwork assets. To edit with the approved typography, install the included Lora and Montserrat fonts. The icon illustrations and logo are image assets, not editable drawing paths inside PowerPoint.

The six delivery stages are official user-supplied methodology. Optimize / Grow and the Regrowth narrative label remain proposed, as shown on the slide. The loop returns operational learning to Discover and Design.

Technical review: package, geometry, fonts and re-import checks passed. The final PPTX was rendered by the artifact runtime; its renderer substituted text faces despite the correctly encoded fonts. The PNG/SVG use the same authored composition with genuine font outlines. Native PowerPoint behavior has not been tested. The source and review reports remain in the private build folder.
