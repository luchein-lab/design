CAPPTUS — ICON SYSTEM V2
Approved for GitHub replacement on October 2, 2026.

CONTENTS
7 unchanged transparent Capptus Way editorial illustrations.
7 new compact native SVGs with transparent 32/64/128/256px PNG exports.
16 new interface SVGs on a 24x24 grid with rounded 2px strokes; PNG previews at 96px.
Reference board PNG + self-contained SVG with outlined Lora and Montserrat.
Selected primary methodology logo SVG/PNG exports.

STAGES
Seedling / Discover; Budding / Design; Growing / Build; Nurturing / Integrate;
Pruning / Test / Train; Harvest / Deploy.
Regrowth / Optimize / Grow remains a proposed seventh stage and narrative name.
Approval of the visual set does not change the operational status of that extension.

USAGE
Illustrations: use 128px or larger, keep full silhouettes and aspect ratios.
Compact icons: use 32–96px on white or Limestone (#F8F7F3). These are hand-drawn
vector interpretations of the motifs, not automatic traces of the illustrations.
The viewBox is -5 -5 110 110, including safety margin; main strokes are 4 units,
with reduced detail at 2–3.5 units and round caps/joins.
Interface icons: use 20–32px inside labeled controls with 44px minimum hit targets.
SVG masters use currentColor; default black, blue available for active states.
Use darker action blue #006D9E where interactive contrast requires it.
Negative primary logo: use the blue plate or transparent white/sand master on a suitable dark surface.
Do not place botanical black linework on dark surfaces. Do not add shadows or stretch assets.
Always write stage meanings and statuses as text; illustrations do not replace labels.

TYPOGRAPHY
Lora Medium 500 for display; Montserrat 400 body and 500/600 UI.
The board lettering is outlined and displays without installed fonts.

VERIFICATION
SVG structure and PNG sizes/transparency checked; board and 32px proof visually reviewed.
Repository integrity, generated output and local links checked.
Application/browser rendering and interaction validation remain pending.
Earlier v1 files remain in the archive and are absent from the active library.
