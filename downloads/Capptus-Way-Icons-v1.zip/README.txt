THE CAPPTUS WAY — Illustration kit v1

Six user-confirmed stages: Seedling/Discover, Budding/Design, Growing/Build, Nurturing/Integrate, Pruning/Test / Train, Harvest/Deploy.
Seventh stage: Optimize / Grow, suggested by the user. Botanical label Regrowth / Rebrote is a design proposal.

Seven original transparent PNGs, generation prompts, and a proposed Capptus Way logo in editable SVG and PNG. Corporate Capptus logo unchanged.
Use illustration PNGs on white or #F8F7F3 backgrounds. Recommended presentation/web size: 96px or larger. These are raster illustrations, not vector UI glyphs. Keep aspect ratio and preserve alpha. Do not stretch, add shadows or place black linework on dark backgrounds.

Operational learning after Deploy feeds Discover and Design. Logo proposal is not approved. Published in the Capptus design-system showcase at github.com/luchein-lab/design.

Verification: alpha and file dimensions checked automatically; contact sheet inspected visually. Live browser verification not performed.
